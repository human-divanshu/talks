<!doctype html>
<html>
<head>
    <?php require_once("common-head.php"); ?>
    <title>Website Name</title>
</head>
<body>
<?php require_once("nav.php"); ?>
    

    
<?php require_once("footer.php"); ?>
</body>
</html>

<script src="js/jquery-latest.min.js"></script>
<script src="js/bootstrap.min.js"></script>
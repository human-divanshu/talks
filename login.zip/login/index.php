<?php
require_once("db.php");


if(loggedin()){
	header("Location: dashboard.php");
	exit();
} else {
	trylogin();
}
?>
<html>
<head>
	<title>Login</title>
</head>
<body>

<form action="#" method="post">

	<label for="username">Username</label>
	<input type="text" name="username" id="username">

	<label for="password">Password</label>
	<input type="password" name="password" id="password">

	<button type="submit" name="submit">Login</button>

</form>
<?php
if(isset($_POST['submit'])) {
	
	$user = $_POST['username'];
	$pass = $_POST['password'];

	if(empty($user) || empty($pass)) {
		echo "All fields are required.";
	} else {

		$db = connect();

		$sql = "select count(*) as count from users where username = ? and password = ?";

		$stmt = $db->prepare($sql);

    	$stmt->execute(array($user, $pass));

    	$result = $stmt->fetch(PDO::FETCH_ASSOC);

		$db = null;

		if($result['count'] == 1) {

			$_SESSION['username'] = $user;
			setcookie("username", $user, time() + (86400 * 30), "/"); 
			header("Location: dashboard.php");

			exit();
		} else {
			echo "Username / password did not match.";
		}
	}

}
?>
</body>
</html>
<?php
require_once("db.php");

// check login

if(!loggedin()){
	header("Location: index.php");
	exit();
}

?>
Welcome to dashboard!
<br>
<a href="logout.php">logout</a>
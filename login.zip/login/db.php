<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

function connect() 
{    
    $db = new PDO('mysql:host=localhost;dbname=abc;charset=utf8', 'root', 'root');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    return $db;
}

function loggedin()
{
	if(isset($_SESSION['username']))
		return True;
	return False;
}

function trylogin()
{
	if(isset($_COOKIE['username'])){
		$user = $_COOKIE['username'];
		if($user != "out") {
			$_SESSION['username'] = $user;
			header("Location: dashboard.php");
			exit();
		}
	}
}

?>
<?php


session_start();
unset($_SESSION['username']);
session_destroy();
setcookie("username", "out", time() + (86400 * 30), "/"); 
header("Location: index.php");
exit();
?>